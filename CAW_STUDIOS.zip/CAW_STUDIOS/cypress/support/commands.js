Cypress.Commands.add('TableDataBtn', () => cy.get('summary'))

Cypress.Commands.add('JsonData', () => cy.get('#jsondata'))

Cypress.Commands.add('RefreshTable', () => cy.get('button[id="refreshtable"]'))

Cypress.Commands.add('Row1', () => cy.get('#dynamictable > :nth-child(2)'))

Cypress.Commands.add('Row2', () => cy.get('#dynamictable > :nth-child(3)'))

Cypress.Commands.add('Row3', () => cy.get('#dynamictable > :nth-child(4)'))

Cypress.Commands.add('Row4', () => cy.get('#dynamictable > :nth-child(5)'))

Cypress.Commands.add('Row5', () => cy.get('#dynamictable > :nth-child(6)'))

Cypress.Commands.add('Row6', () => cy.get('#dynamictable > :nth-child(7)'))