describe('Assignment for SDET - CAW Studios', () => {
  const url = 'https://testpages.herokuapp.com/styled/tag/dynamic-table.html'
  const jsonString = `[{"name": "Bob", "age": 20, "gender": "male"},
                            {"name": "George", "age": 42, "gender": "male"},
                            {"name": "Sara", "age": 42, "gender": "female"},
                            {"name": "Conor", "age": 40, "gender": "male"},
                            {"name": "Jennifer", "age": 42, "gender": "female"}]`;
  beforeEach(() => {
    cy.fixture('data').as('DataJson')
  })
  it('Should verify landing into the page and performing the actions as per the instructions ', function () {
    cy.visit(url)
    cy.TableDataBtn().click()
    cy.JsonData().clear()
    cy.JsonData().type(jsonString,
      { parseSpecialCharSequences: false })
    cy.RefreshTable().click()
    cy.JsonData().should('be.visible')
    cy.Row1().should('contain', 'name')
      .and('contain', 'age')
      .and('contain', 'gender')
    cy.Row2().should('contain', 'Bob')
      .and('contain', '20')
      .and('contain', 'male')
    cy.Row3().should('contain', 'George')
      .and('contain', '42')
      .and('contain', 'male')
    cy.Row4().should('contain', 'Sara')
      .and('contain', '42')
      .and('contain', 'female')
    cy.Row5().should('contain', 'Conor')
      .and('contain', '40')
      .and('contain', 'male')
    cy.Row6().should('contain', 'Jennifer')
      .and('contain', '42')
      .and('contain', 'female')
  })

})



